package ViewPatientList;

public class PatientInfo {
	
	public String getPatientID() {
		return patientID;
	}


	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}


	public String getPatientName() {
		return patientName;
	}


	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	private String patientID, patientName, gender;
	private int age;
	
	
	public PatientInfo(String patientID, String patientName, String gender, int age) {
		super();
		this.patientID = patientID;
		this.patientName = patientName;
		this.gender = gender;
		this.age = age;
	}
	
	
	
	
}
