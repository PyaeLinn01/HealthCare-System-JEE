Readme
Latest Update - March 04, 2024
CST-4104: Data Structure and Algorithms with Java Project
FITFINITY
HOSPITAL MANAGEMENT SYSTEM & ONLINE BOOKING SERVICE


About
Fitfinity Java Web Application Project 
by UIT Batch-9 Second Year, Section - A, Group - Fitfinity Team

Members (Fitfinity Team)
Htet Paing Linn (Thanata-1785)
-Frontend
-Flowchart Design
-Patient Dashboard
-Admin Dashboard
-Doctors’ Schedule System
-Patient Online Booking System


Htet Myet Zaw (Thanata-1794)
-Patient Dashboard
-Doctor Dashboard
-Salary Management
-History Management
-Powerpoint Design

Aung Kaung Myat (Thanata-1770)
-BMI Calculator
-Doctor Dashboard
-Powerpoint Design

Pyae Linn (Thanata-1864)
-Feedback System
-Contact Us
-Captcha

Thaw Wai Yan Hein (Thanata-1774)
-Tester
-BMI Calculator

Usage
-For all healthcare service providers, adminstration, doctors and staff and patients
to computerise healthcare data and able to manage data dynamically.

Installation
-Download source code named fitfinity and sql file
-Start up Eclipse and run the workspace using downloaded source code
-Import local sql from downloaded sql file
-Finally, whole system is able to run.

Thank you.


Copyright ©2024 Fitfinity Team. All rights reserved.